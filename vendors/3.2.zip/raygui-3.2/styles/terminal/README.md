style: terminal
----------------
Start your terminal and type your commands! Feel the connection the data flow, that's your style!

![terminal style table](style_table.png)

screenshot
-----------

![terminal style screen](screenshot.png)

about font
-----------
"Mecha" font by Captain Falcon.

100% free font, downloaded from dafont.com: [mecha-cf](https://www.dafont.com/mecha-cf.font)
