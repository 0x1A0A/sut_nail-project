style: sunny
-------------
Sweet, colorful, sunny! Inspired by the [Playdate](https://play.date/) console and its [pulp](https://play.date/pulp/) editor!

![sunny style table](style_table.png)

screenshot
-----------

![sunny style screen](screenshot.png)

about font
-----------
"Generic Mobile System" font by Jayvee Enaguas (HarvettFox96).

CC0 free font, downloaded from dafont.com: [generic-mobile-system](https://www.dafont.com/es/generic-mobile-system.font)
