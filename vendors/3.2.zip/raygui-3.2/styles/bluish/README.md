style: bluish
--------------
Like a breeze, a slight touch of color cover the clear sky, a spacious and relaxing feeling.

![bluish style table](style_table.png)

screenshot
-----------

![bluish style screen](screenshot.png)

about font
-----------
"Homespun BRK" font by AEnigma (Brian Kent).

100% free font, downloaded from dafont.com: [homespun-brk](https://www.dafont.com/homespun-brk.font)
