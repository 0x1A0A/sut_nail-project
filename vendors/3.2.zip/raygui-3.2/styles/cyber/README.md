style: cyber
-------------
Future is now! Neons and shadows, city never sleeps! Robots waiting in the corners and expensive vending machines! You got the style!

![cyber style table](style_table.png)

screenshot
-----------

![cyber style screen](screenshot.png)

about font
-----------
"Grixel Kyrou 7 Wide" font by [Nikos Giannakopoulos](http://www.grixel.gr/).

100% free font, downloaded from dafont.com: [grixel-kyrou-7-wide](https://www.dafont.com/grixel-kyrou-7-wide.font)
